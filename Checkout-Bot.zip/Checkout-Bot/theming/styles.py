globalStyles = {
    "backgroundLight": "#232323",
    "backgroundDark":"#1E1E1E",
    "primaryAscent": "#402721",
    "primary":"#E22F09",
    "cartedColor":"#ccc61e"
}

