import json


# https://github.com/Hari-Nagarajan/nvidia-bot/blob/master/utils/json_utils.py

def find_values(json_repr, id):
    results = []

    def _decode_dict(a_dict):
        try:
            results.append(a_dict[id])
        except KeyError:
            pass
        return a_dict

    json.loads(json_repr, object_hook=_decode_dict)  # Return value ignored.
    return results


class InvalidAutoBuyConfigException(Exception):
    def __init__(self, message):
        super().__init__(message)
